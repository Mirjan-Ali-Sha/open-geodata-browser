# Bundled dependencies for Open Geodata Browser
